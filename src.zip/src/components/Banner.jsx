import './style/Banner.sass'

function Banner() {
    return(
        <nav>
            <div id="container">
            <div id="texte">
            <p id='bannerTexte'>Chez vous, partout et ailleurs</p>
            </div>
            </div>
        </nav>
    )
}

export default Banner