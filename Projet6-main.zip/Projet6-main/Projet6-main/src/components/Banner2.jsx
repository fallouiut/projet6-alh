import './style/Banner2.sass'

function Banner2() {
    return(
        <nav>
            <div id="bannerImage"></div>
        </nav>
    )
}

export default Banner2